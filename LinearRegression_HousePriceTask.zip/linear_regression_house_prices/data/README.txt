Download dataset from: https://www.kaggle.com/c/house-prices-advanced-regression-techniques/data
Place train.csv in the data folder.