
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Load dataset (download from Kaggle and place in 'data/train.csv')
data = pd.read_csv('data/train.csv')

# Selecting relevant features
features = ['GrLivArea', 'BedroomAbvGr', 'FullBath']
X = data[features]
y = data['SalePrice']

# Splitting data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Linear Regression Model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse:.2f}")

# Example prediction
example = pd.DataFrame([[1500, 3, 2]], columns=features)
predicted_price = model.predict(example)[0]
print(f"Predicted price for 1500 sqft, 3 BR, 2 Bath: ${predicted_price:.2f}")
